# Writing some helper functions

import sys
import os
import numpy as np
import collections


def make_surface_proj(atom_box):
    #Given an atom box (matrix with 1s where atoms are), determine the surface projection and the atom type mask
    
    surface_proj = np.zeros(shape=(atom_box.shape[0], atom_box.shape[1]))
    atom_type_mask = np.zeros(shape=surface_proj.shape)
    for i in range(surface_proj.shape[0]):
        for j in range(surface_proj.shape[1]):
            try:
                surface_proj[i,j] = np.max(np.where(atom_box[i,j,:]>0))
                max_arg = np.argmax(np.where(atom_box[i,j,:]>0))
                if atom_box[i,j,max_arg]==1: atom_type_mask[i,j]=1                    
            except ValueError:
                surface_proj[i,j] = 0
    return surface_proj, atom_type_mask

def calc_roughness(surface_projection):
    #Calculate the roughness, given a surface projection
    N = surface_projection.shape[0]
    M = surface_projection.shape[1]
    zbar = np.mean(surface_projection)
    z_sum = 0
    for i in range(N):
        for j in range(M):
            z_sum+=((surface_projection[i,j] - zbar )**2)
    rms_roughness = np.sqrt((1.0/(N*M))*z_sum)
    return rms_roughness

def get_state_reward(sim_model, latt, target_roughness):
    '''Given an input of the simulation model this function returns the state and reward'''
    #To get the final state put atoms into atom box
    arr = sim_model.kmc.get_conf()
    arr_1 = np.array(arr[0])
    
    full_atom_box = np.zeros((latt.shape[0],latt.shape[1],latt.shape[2]))
    for i,j,k in arr_1:
        full_atom_box[i,j,k]=1
        
    state_image, state_mask = make_surface_proj(full_atom_box)
    state_image = state_image - state_image.min()
    
    reward = 0
    
    frac_b_atoms = np.sum(state_mask) / np.prod(state_mask.shape)
    
    #changing the state to be the rms value, the current rates and the current temperature, and fraction of B atoms on surface
    
    dep_rate_a = np.copy(sim_model.kmc.etree.rates[0])
    dep_rate_b = np.copy(sim_model.kmc.etree.rates[1])
    current_temp = np.copy(sim_model.kmc.temp)
    
    #for ease, we divide the temp by 1000 so it is roughly same scale as other features.
    state_numeric = np.zeros(shape=(1,4),dtype = np.float32)

    state_numeric[0,0] =dep_rate_a
    state_numeric[0,1] =dep_rate_b
    state_numeric[0,2] =current_temp/1000
    state_numeric[0,3] =frac_b_atoms
    
    return [state_image, state_numeric], reward


# +
def get_incremented_rates(existing_rates, current_temp, action):
    
    #Given some rates and actions, increment appropriately and return updated rates

    #actions will be a vector of length (3), with each entry clipped to [-100,100]
    
    new_rates = []
    
    action_dep_rate_a = action[0]/25.0
    new_dep_rate_a = existing_rates[0] + action_dep_rate_a
    new_dep_rate_a = np.clip(new_dep_rate_a, 0.01, 0.90)
    new_rates.append(new_dep_rate_a)
    
    action_dep_rate_b = action[1]/25.0
    new_dep_rate_b = existing_rates[1] + action_dep_rate_b
    new_dep_rate_b = np.clip(new_dep_rate_b, 0.01, 0.90)
    new_rates.append(new_dep_rate_b)
    
    #handling the temperature
    action_temp = action[2]*50
    new_temp = current_temp + action_temp
    
    new_diffusion_rates = get_new_diffusion_rates(new_temp)
    
    new_rates.append(new_diffusion_rates[0])
    new_rates.append(new_diffusion_rates[1])
    new_rates.append(new_diffusion_rates[2])
    
    return new_rates, new_temp

def get_new_diffusion_rates(new_temp):
    # The following define the behavior of the diffusion rates with respect to T
    #Best not to change for now.
    
    T = np.linspace(300,1400,1101)
    
    #clip T
    new_temp = np.clip(new_temp, T.min(), T.max())

    rate_same_offset = 0.215
    rate_mix_offset = 0.126 
    rate_diff_offset = 0.0280

    rate_same_slope  = 0.0004199
    rate_mix_slope = 0.00057
    rate_diff_slope  = 2.50E-4 *3
    
    diffusion_rate_same = np.array(rate_same_slope*new_temp + rate_same_offset)
    diffusion_rate_different = np.array(rate_diff_slope*new_temp + rate_diff_offset)
    diffusion_rate_mix = np.array(rate_mix_slope*new_temp + rate_mix_offset)
    
    return [diffusion_rate_same, diffusion_rate_different, diffusion_rate_mix]


def gaussian(x, mu, sig):
    return np.exp(-np.power(x - mu, 2.) / (2 * np.power(sig, 2.)))
