import tensorflow as tf
import tensorflow_probability as tfp
import sklearn
import sklearn.preprocessing
from tensorflow.keras import Model, layers
from tensorflow.keras.models import Sequential
import numpy as np
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.layers import Dense, Conv2D, MaxPool2D, AveragePooling2D, \
UpSampling2D, Reshape, Flatten, Add, Input
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Concatenate
from IPython.display import clear_output
import tensorflow as tf
from tensorflow.keras.models import load_model


tf.keras.backend.set_floatx('float32')

class NeuralNet_A2C(Model):
    #This defines two distinct models
    #One is an actor, another is the critic (value function estimation)
    #Both are fully connected neural networks
    
    def __init__(self,  input_dim=4,  dim_actions=3, num_conv_filters_1=32,
                 num_conv_filters_2=32, num_hidden_nodes_1=128, num_hidden_nodes_2=128,
                 actor_lr = 0.0002, critic_lr = 0.001):
        
        self.num_conv_filter_1 = num_conv_filters_1
        self.num_conv_filter_2 = num_conv_filters_2
        
        self.num_hidden_nodes_1 = num_hidden_nodes_1
        self.num_hidden_nodes_2 = num_hidden_nodes_2
        self.input_dim = input_dim
        self.dim_actions = dim_actions
        self.critic_lr = critic_lr
        self.actor_lr = actor_lr

        super(NeuralNet_A2C, self).__init__()
        self.actor = self.build_actor()
        self.critic = self.build_critic()
        self.actor.optimizer =  tf.keras.optimizers.Adam(learning_rate=self.actor_lr)
        self.critic.optimizer =  tf.keras.optimizers.Adam(learning_rate=self.critic_lr)
    
    def build_actor(self):
        
        InputImage = Input(shape=(16,16,1))
        InputNumeric = Input(shape=(4,))

        cnet = layers.Conv2D(filters = self.num_conv_filter_1,  kernel_size = (4,4), strides=(2,2), 
                             activation=tf.nn.tanh,
                               kernel_initializer='he_uniform',  name='conv1')(InputImage)
        cnet = layers.AveragePooling2D()(cnet)
        cnet = layers.Conv2D(self.num_conv_filter_2, kernel_size = (3,3), strides=(1,1), activation=tf.nn.tanh,
                                kernel_initializer='he_uniform', name='conv2') (cnet)
        cnet = layers.Flatten()(cnet)
        cnet = Model(inputs = InputImage, outputs = cnet)


        numeric = layers.Dense(self.num_hidden_nodes_1, activation=tf.nn.tanh,
                                 kernel_initializer='he_uniform') (InputNumeric)

        numeric = layers.Dense(self.num_hidden_nodes_2, activation=tf.nn.tanh,
                               kernel_initializer='he_uniform')(numeric)

        numeric = Model(inputs = InputNumeric, outputs = numeric)

        combined = layers.concatenate([cnet.output, numeric.output])

        combined_network = layers.Dense(self.num_hidden_nodes_1, activation = tf.nn.tanh)(combined)

        combined_network = layers.Dense(self.num_hidden_nodes_2, activation=tf.nn.tanh)(combined_network)

        combined_network = layers.Dense(self.dim_actions*2, activation = 'linear', kernel_initializer='he_uniform',
                                        name='output_actions_layer')(combined_network)
        
        actor = Model(inputs = [cnet.input, numeric.input], outputs = combined_network)
        

        return actor

    def build_critic(self):
        #critic neural network
        InputImage = Input(shape=(16,16,1))
        InputNumeric = Input(shape=(4,))

        cnet = layers.Conv2D(filters = self.num_conv_filter_1,  kernel_size = (4,4), strides=(2,2), activation=tf.nn.relu,
                               kernel_initializer='he_uniform',  name='conv1')(InputImage)
        cnet = layers.AveragePooling2D()(cnet)
        cnet = layers.Conv2D(self.num_conv_filter_2, kernel_size = (3,3), strides=(1,1), activation=tf.nn.relu,
                                kernel_initializer='he_uniform', name='conv2') (cnet)
        cnet = layers.Flatten()(cnet)
        cnet = Model(inputs = InputImage, outputs = cnet)


        numeric = layers.Dense(self.num_hidden_nodes_1, activation=tf.nn.tanh,
                                 kernel_initializer='he_uniform') (InputNumeric)

        numeric = layers.Dense(self.num_hidden_nodes_2, activation=tf.nn.tanh,
                               kernel_initializer='he_uniform')(numeric)

        numeric = Model(inputs = InputNumeric, outputs = numeric)

        combined = layers.concatenate([cnet.output, numeric.output])

        combined_network = layers.Dense(self.num_hidden_nodes_1, activation = tf.nn.tanh)(combined)

        combined_network = layers.Dense(self.num_hidden_nodes_2, activation=tf.nn.tanh)(combined_network)

        combined_network = layers.Dense(1, activation = 'linear', kernel_initializer='he_uniform',
                                        name='value_estimate')(combined_network)
        
        critic = Model(inputs = [cnet.input, numeric.input], outputs = combined_network)
        
        return critic

    # define forward pass
    def call(self, states):

        actions_output = tf.reshape(self.actor(states),(-1,self.dim_actions,2))
        value_estimate = self.critic(states)
 
        return actions_output, value_estimate

#Helper functions
def smooth_window(x, N):
    return np.convolve(x, np.ones((N,))/N, mode='valid')

def make_surface_proj(atom_box):
    #Given an atom box (matrix with 1s where atoms are), determine the surface projection
    
    surface_proj = np.zeros(shape=(atom_box.shape[0], atom_box.shape[1]))
    for i in range(surface_proj.shape[0]):
        for j in range(surface_proj.shape[1]):
            try:
                surface_proj[i,j] = np.max(np.where(atom_box[i,j,:]==1))
            except ValueError:
                surface_proj[i,j] = 0
    return surface_proj

def calc_roughness(surface_projection):
    #Calculate the roughness, given a surface projection
    N = surface_projection.shape[0]
    M = surface_projection.shape[1]
    zbar = np.mean(surface_projection)
    z_sum = 0
    for i in range(N):
        for j in range(M):
            z_sum+=((surface_projection[i,j] - zbar )**2)
    rms_roughness = np.sqrt((1.0/(N*M))*z_sum)
    return rms_roughness

